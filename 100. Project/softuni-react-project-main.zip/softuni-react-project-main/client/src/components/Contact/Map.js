export const Map = () => {
    
    return (
        <iframe 
            title="map"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7390.411602537908!2d23.319318960228227!3d42.684940833238954!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40aa850fb6af8ebb%3A0x87a301b7860955b9!2sNational%20Palace%20of%20Culture!5e0!3m2!1sen!2sbg!4v1679669697706!5m2!1sen!2sbg" 
            width="100%" 
            height="300px" 
        />
    );
};