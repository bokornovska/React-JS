import './Home.css'
import { Banner } from "./Banner";
import { memo } from 'react';

const Home = () => {
    return (
        <>
          <Banner />


        </>
    );
};

export default memo(Home);