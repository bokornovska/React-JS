export const admins = [
    "60f0cf0b-34b0-4abd-9769-8c42f830dffc",
    "35c62d76-8152-4626-8712-eeb96381bea8",
    "847ec027-f659-4086-8032-5173e2f9c93a",
]