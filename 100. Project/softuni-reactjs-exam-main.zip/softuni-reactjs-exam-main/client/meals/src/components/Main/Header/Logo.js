export const Logo = () => {
    return (
        <a href="index.html" className="logo">
            <img
                src={require("../../../styles/images/klassy-logo.png")}
                align="klassy cafe html template"
                alt="Img is missing"
            />
        </a>
    );
}