export default function Footer (){
    return <footer>All rights reserved &copy;</footer>
}