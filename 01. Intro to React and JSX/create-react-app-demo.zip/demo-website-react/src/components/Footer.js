export function Footer () {
    return (
        <section className="container-fluid footer_section">
        <p>
          &copy; 2019 All Rights Reserved By
          <a href="https://html.design/">Free Html Templates</a>
        </p>
      </section> 
    )
}