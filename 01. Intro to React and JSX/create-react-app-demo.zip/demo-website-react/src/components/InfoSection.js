export function InfoSection () {

    return (
        <section className="info_section layout_padding">
        <div className="container">
          <div className="info_social">
            <div>
              <a href="">
                <img src="images/fb.png" alt="" />
              </a>
            </div>
            <div>
              <a href="">
                <img src="images/twitter.png" alt="" />
              </a>
            </div>
            <div>
              <a href="">
                <img src="images/linkedin.png" alt="" />
              </a>
            </div>
            <div>
              <a href="">
                <img src="images/insta.png" alt="" />
              </a>
            </div>
          </div>
          <div>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
            </p>
          </div>
        </div>
      </section>
      
    )
}