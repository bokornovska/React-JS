
/* eslint-disable */

import { HeroSection } from "./components/HeroSection";
import { AboutSection } from "./components/AboutSection";
import { ServiceSection } from "./components/ServiceSection";
import { PortfolioSection } from "./components/PortfolioSection";
import { NewsSection } from "./components/NewsSection";
import { SubscribeSection } from "./components/SubscribeSection";
import { ClientSection } from "./components/ClientSection";
import { ContactSection } from "./components/ContactSection";
import { InfoSection } from "./components/InfoSection";
import { Footer } from "./components/Footer";

function App() {
  return (
    <div>
        <HeroSection />
        <AboutSection />
        <ServiceSection />
        <PortfolioSection />
        <NewsSection />
        <SubscribeSection />
        <ClientSection />
        <ContactSection />
        <InfoSection />
        <Footer />      
    </div>
  );
}

export default App;
